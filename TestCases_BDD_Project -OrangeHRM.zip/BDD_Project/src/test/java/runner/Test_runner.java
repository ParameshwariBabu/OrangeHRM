package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		features = {"src\\test\\java\\Feature\\feature.feature"},
		dryRun = true,		
		glue = "stepdef"
		)
public class Test_runner extends AbstractTestNGCucumberTests {

}
