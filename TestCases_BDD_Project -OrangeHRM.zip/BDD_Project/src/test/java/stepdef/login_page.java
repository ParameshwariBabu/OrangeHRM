package stepdef;

import org.openqa.selenium.chrome.ChromeDriver;
import java.time.Duration;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class login_page {

    public static WebDriver driver;

    @Given("User should be in OrangeHRM login page")
    public void user_should_be_in_orange_hrm_login_page() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
    }

    @When("User enter the username")
    public void user_enter_the_username() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys("Admin");
    }

    @When("User enter the password")
    public void user_enter_the_password() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("admin123");
    }

    @When("user click on login button")
    public void user_click_on_login_button() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.xpath("//button[@type='submit']")).click();
    }

    @Then("User will be in home page of OrangeHRM")
    public void user_will_be_in_home_page_of_OrangeHRM() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        WebElement homepage = driver.findElement(By.className("oxd-brand"));
        Assert.assertTrue(homepage.isDisplayed(), "User is not in Homepage");
        System.out.println("User is in Homepage now");
    }

    @When("user click on the PIM side menu")
    public void user_click_on_the_pim_side_menu() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        Actions actions = new Actions(driver);
        WebElement PIM = driver.findElement(By.xpath("(//a[@class='oxd-main-menu-item'])[2]"));

        Assert.assertTrue(PIM.isDisplayed(), "PIM menu is not visible");
        actions.moveToElement(PIM).click().perform();
        System.out.println("PIM menu is clicked");
    }

    @Then("User should redirect to the employee list page")
    public void user_should_redirect_to_the_employee_list_page() {
        WebElement employeeListTab = driver.findElement(By.xpath("//li[@class='oxd-topbar-body-nav-tab --visited']"));
        employeeListTab.click();
    }
    
    @And("user should able to view the employee information page")
    public void user_should_to_view_the_employee_information_page() {
    	driver.findElement(By.xpath("//a[text()='Employee List']")).isSelected();
    }

    @When("user enters employee first name and last name")
    public void user_enters_employee_first_name_and_last_name() throws Exception {
        String[][] employees = {
            {"S", "A"},
            {"D", "B"},
            {"F", "C"}
        };

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JavascriptExecutor js = (JavascriptExecutor) driver;

        for (String[] e : employees) {
            String firstName = e[0];
            String lastName = e[1];

            System.out.println("Adding employee: " + firstName + " " + lastName);

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@class='oxd-topbar-body-nav-tab-item'])[2]"))).click();

            WebElement firstNameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("firstName")));
            firstNameField.clear();
            firstNameField.sendKeys(firstName);

            WebElement lastNameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("lastName")));
            lastNameField.clear();
            lastNameField.sendKeys(lastName);

            Thread.sleep(1000);

            WebElement saveButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));
            js.executeScript("arguments[0].scrollIntoView(true);", saveButton);
            js.executeScript("arguments[0].click();", saveButton);
            System.out.println("Clicked Save button successfully.");

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("oxd-toaster_1")));
            driver.findElement(By.xpath("//a[text()='Employee List']")).click();
        }
    }
    @Then("user should able to view the employee information in employee list page")
    public void user_should_able_to_view_the_employee_information_in_employee_list_page() throws InterruptedException, TimeoutException {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        JavascriptExecutor js = (JavascriptExecutor) driver;
         
        
        String[] employeeNamesToSearch = {"S A", "D B", "F C"};

        for (String name : employeeNamesToSearch) {
        	
            driver.findElement(By.xpath("//a[text()='Employee List']")).click(); 

            Actions actions = new Actions(driver);
            WebElement searchInput = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Type for hints...']")));
            actions.moveToElement(searchInput).perform();

	        searchInput.click();
	        searchInput.clear();
	        searchInput.sendKeys(name);

	        WebElement searchButton = driver.findElement(By.xpath("//button[text()=' Search ']"));
	        	
	        if(searchButton.isDisplayed() && searchButton.isEnabled() ) {	
	        	searchButton.click();
	        	System.out.println("Search button is clicked");
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, 0);");
	        }
	        else {
	        	System.out.println("Search button is not clicked");	
	        }
	        
            Thread.sleep(8000);

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='oxd-table-body']")));
            Thread.sleep(15000);

            WebElement recordTable = driver.findElement(By.xpath("//div[@class='oxd-table-body']"));
            js.executeScript("arguments[0].scrollIntoView(true);", recordTable);
            Thread.sleep(8000);
            
            if(recordTable.isDisplayed()) {
            	System.out.println("Name verified");
            }
            else {
            	System.out.println("Name not found");
            }
         
            Thread.sleep(2000);
        }
    }

    
    @Then("user Logout from the dashboard")
    public void user_logout_from_the_dashboard() throws InterruptedException {
    	Thread.sleep(10000); 
    	driver.findElement(By.className("oxd-userdropdown-name")).click();
        WebElement logoutButton = driver.findElement(By.xpath("//ul[@class=\"oxd-dropdown-menu\"]//li[4]"));
        logoutButton.click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.xpath("//input[@placeholder='Username']")).isDisplayed();
        System.out.println("Logout from the dashboard");
        }
}